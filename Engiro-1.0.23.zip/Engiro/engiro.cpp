/*
    Engiro.cpp - Library to define the Engiro-Zero SAMD board pinout to use in Arduino IDE environment.
    Created by Teng Kong Leong, August 21, 2023
    Released into the public domain.
*/

/*
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * + Pin number +  ENGIRO pin  |  SAMD PIN   | Comments
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * >>>>>> LED INDICATOR <<<<<<
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 13         | LED1         |  PA17  | LED INDICATOR 1
 * | 10         | LED2         |  PA18  | LED INDICATOR 2
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * >>>>>> COMMUNICATION MODULE <<<<<<
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 0          | IO1          |  PA11  | COMMUNICATION MODULE IO 1
 * | 9          | IO2          |  PA07  | COMMUNICATION MODULE IO 2
 * | 4          | IO3          |  PA08  | COMMUNICATION MODULE IO 3
 * | 12         | IO4          |  PA19  | COMMUNICATION MODULE IO 4
 * | 6          | IO5          |  PA20  | COMMUNICATION MODULE IO 5
 * | 7          | IO6          |  PA21  | COMMUNICATION MODULE IO 6
 * | 1          | UART1_TX     |  PA10  | COMMUNICATION MODULE TRANSMIT
 * | 3          | UART1_RX     |  PA09  | COMMUNICATION MODULE RECEIVE
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * >>>>>> MODBUS <<<<<<
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 42         | TX_ENABLE    |  PA03  | MODBUS TRANSMIT ENABLE
 * | 43         | RX_ENABLE    |  PA02  | MODBUS RECEIVE ENABLE
 * | 19         | UART0_TX     |  PB02  | MODBUS TRANSMIT
 * | 25         | UART0_RX     |  PB03  | MODBUS RECEIVE
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * >>>>>> ACCELEROMETER <<<<<<
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 5          | SPI_CS       |  PA15  | SPI CHIP SELECT
 * | 24         | SPI_SCK      |  PB11  | SPI CLOCK
 * | 22         | SPI_MISO     |  PA12  | SPI MASTER-IN SLAVE-OUT
 * | 23         | SPI_MOSI     |  PB10  | SPI MASTER-OUT SLAVE-IN
 * | 38         | ACC_INT_1    |  PA13  | ACCELEROMETER INTERRUPT INPUT
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * >>>>>> SENSOR INPUT / ANALOG INPUT MEASUREMENT <<<<<<
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 8          | BATTERY      |  PA06  | BATTERY VOLTAGE MEASUREMENT
 * | 17         | ISENSE       |  PA04  | 4~20MA INPUT MEASUREMENT
 * | 18         | VSENSE       |  PA05  | 0~10V INPUT MEASUREMENT
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * >>>>>> ISOLATED INPUT / OUTPUT <<<<<<
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 16         | SIGNAL1      |  PB09  | ISOLATED OUTPUT 1
 * | 15         | SIGNAL2      |  PB08  | ISOLATED OUTPUT 2 
 * | 26         | SIG1         |  PA27  | ISOLATED INPUT 1
 * | 27         | SIG2         |  PA28  | ISOLATED INPUT 2
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * >>>>>> AUX POWER CONTROL <<<<<<
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 11         | AUX_PWR      |  PA16  | AUXILIARY POWER ENABLE/DISABLE
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * >>>>>> DEBUG UART <<<<<<
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 20         | UART2_TX     |  PA22  | DEBUG TX
 * | 21         | UART2_RX     |  PA23  | DEBUG RX
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * >>>>>> SYSTEM <<<<<<
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 28         | USB_N        |  PA24  | USB_NEGATIVE  
 * | 29         | USB_P        |  PA25  | USB_POSITIVE  
 * | 44         | SWCLK        |  PA30  | SERIAL WIRE DEBUG CLOCK
 * | 45         | SWDIO        |  PA31  | SERIAL WIRE DEBUG INPUT/OUTPUT
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 */


#include "Arduino.h"
#include "engiro.h"
#include "wiring_private.h"
//#include "Wire.h"
#include "SPI.h"


// >>>>>> INITIALIZE PIN DIRECTION AND FUNCTION BASED ON ENGIRO-ZERO BOARD <<<<<<
unsigned int Engiro::Battery() {    // READ INCOMING SUPPLY VOLTAGE
    analogReference(AR_DEFAULT);    // ADC REFERENCE VOLTAGE = 3.3V
    analogReadResolution(12);       // ADC RESOLUTION = 12-BIT
    return analogRead(BATTERY);
}


unsigned int Engiro::AnalogVoltageRead() {  // READ INCOMING 0-10V ANALOG VOLTAGE
    analogReference(AR_DEFAULT);    // ADC REFERENCE VOLTAGE = 3.3V
    analogReadResolution(12);       // ADC RESOLUTION = 12-BIT
    return analogRead(VSENSE);
}


unsigned int Engiro::AnalogCurrentRead() {  // READ INCOMING 4-20MA CURRENT
    analogReference(AR_DEFAULT);    // ADC REFERENCE VOLTAGE = 3.3V
    analogReadResolution(12);       // ADC RESOLUTION = 12-BIT
    return analogRead(ISENSE);
}


void Engiro::Led1_On() {                    // Turn On LED #1
    pinMode(LED1, OUTPUT);
    digitalWrite(LED1, HIGH);
}


void Engiro::Led2_On() {                    // Turn On LED #2
    pinMode(LED2, OUTPUT);
    digitalWrite(LED2, HIGH);
}


void Engiro::Led1_Off() {                    // Turn On LED #1
    pinMode(LED1, OUTPUT);
    digitalWrite(LED1, LOW);
}


void Engiro::Led2_Off() {                    // Turn On LED #2
    pinMode(LED2, OUTPUT);
    digitalWrite(LED2, LOW);
}


void Engiro::AuxPwr_Enable() {              // Turn On +5V Supply
    pinMode(AUX_PWR, OUTPUT);
    digitalWrite(AUX_PWR, HIGH);
}


void Engiro::AuxPwr_Disable() {             // Turn Off +5V Supply
    pinMode(AUX_PWR, OUTPUT);
    digitalWrite(AUX_PWR, LOW);
}


void Engiro::Modbus_Transmit_Enable() {     // Set RS485 Driver to Transmit
    pinMode(TX_ENABLE, OUTPUT);            // DE
    pinMode(RX_ENABLE, OUTPUT);            // RE#
    digitalWrite(TX_ENABLE, HIGH);         // DE = 1
    digitalWrite(RX_ENABLE, LOW);          // RE = 0
}


void Engiro::Modbus_Receive_Enable() {      // Set RS485 Driver to Receive
    pinMode(TX_ENABLE, OUTPUT);            // DE
    pinMode(RX_ENABLE, OUTPUT);            // RE#
    digitalWrite(TX_ENABLE, LOW);          // DE = 0
    digitalWrite(RX_ENABLE, LOW);          // RE = 0
}


void Engiro::Modbus_Sleep() {               // Shutdown RS485 Driver
    pinMode(TX_ENABLE, OUTPUT);            // DE
    pinMode(RX_ENABLE, OUTPUT);            // RE#
    digitalWrite(TX_ENABLE, LOW);          // DE = 0
    digitalWrite(RX_ENABLE, HIGH);         // RE = 1
}


void Engiro::Uart_Initialize() {
    // ****** UART COMMUNICATION PORT DECLARATION ******
    /*
        UART 0 - MODBUS PORT (RS485)
    */    
    pinPeripheral(UART0_TX, PIO_SERCOM_ALT);  // SET PORT TO SERCOM FUNCTION
    pinPeripheral(UART0_RX, PIO_SERCOM_ALT);  // SET PORT TO SERCOM FUNCTION

    /*
        UART 1 - COMMUNICATION MODULE PORT
    */    
    pinPeripheral(UART1_TX, PIO_SERCOM);   // SET PORT TO SERCOM FUNCTION
    pinPeripheral(UART1_RX, PIO_SERCOM);   // SET PORT TO SERCOM FUNCTION

    /*
        UART 2 - DEBUG PORT
    */    
    pinPeripheral(UART2_RX, PIO_SERCOM);  // SET PORT TO SERCOM FUNCTION
    pinPeripheral(UART2_TX, PIO_SERCOM);  // SET PORT TO SERCOM FUNCTION
    // *************************************************
}


Uart Debug(&sercom3, UART2_RX, UART2_TX, SERCOM_RX_PAD_1, UART_TX_PAD_0);           // MAP PORT A22 & A23 TO UART (SERCOM3)
void SERCOM3_Handler()
{
    Debug.IrqHandler();
}


Uart ComSerial(&sercom0, UART1_RX, UART1_TX, SERCOM_RX_PAD_1, UART_TX_PAD_2);         // MAP PORT A9 & A10 TO UART (SERCOM0)
void SERCOM0_Handler()
{
    ComSerial.IrqHandler();
}


Uart Modbus(&sercom5, UART0_RX, UART0_TX, SERCOM_RX_PAD_1, UART_TX_PAD_0);          // MAP PORT B2 & B3 TO UART (SERCOM5)
void SERCOM5_Handler()
{
    Modbus.IrqHandler();
}


void Engiro::Acc_Initialize() {
    pinMode(ACC_INT_1, INPUT);     // Accelerometer Interrupt Input
    pinMode(SPI_CS, OUTPUT);     // CS (1:I2C, 0:SPI)    
    digitalWrite(SPI_CS, HIGH);  // CS = 1
}


void Engiro::Acc_RW_Enable(){
    digitalWrite(SPI_CS, LOW);  // CS = 0
}


void Engiro::Acc_RW_Disable() {
    digitalWrite(SPI_CS, HIGH);  // CS = 1
}


void Engiro::LoRa_RAK3172_Enable() {
    pinMode(IO5, OUTPUT);
    pinMode(IO4, OUTPUT);
    digitalWrite(IO5, HIGH);
    digitalWrite(IO4, HIGH);
}


void Engiro::LoRa_RAK3172_Disable() {
    pinMode(IO5, OUTPUT);
    pinMode(IO4, OUTPUT);
    digitalWrite(IO5, LOW);
    digitalWrite(IO4, LOW);
}


void Engiro::LTE_enable() {
    // IO1 - Reset
    // IO2 - PwrKey
    // IO3 - PwrEnable
    pinMode(IO1, OUTPUT);       // Set IO1 to output
    pinMode(IO2, OUTPUT);       // Set IO2 to output
    pinMode(IO3, OUTPUT);       // Set IO3 to output
    digitalWrite(IO1, LOW);     // Set Reset (IO1) to logic low
    digitalWrite(IO3, HIGH);    // Set PwrEn (IO3) to logic high
    delay(1000);                // Delay 1sec
    digitalWrite(IO2, HIGH);    // Set PwrKey (IO2) to logic high
    delay(1000);                // Delay 1sec
    digitalWrite(IO2, LOW);     // Set PwrKey (IO2) to logic low
}


void Engiro::LTE_reset() {
    // IO1 - Reset
    // IO2 - PwrKey
    // IO3 - PwrEnable
    pinMode(IO3, OUTPUT);       // Set IO3 to output
    digitalWrite(IO3, LOW);     // Set PwrEn to logic low
    delay(5000);
    digitalWrite(IO3, HIGH);    // Set PwrEn to logic high
}

void Engiro::LTE_disable() {
    // IO1 - Reset
    // IO2 - PwrKey
    // IO3 - PwrEnable
    pinMode(IO1, OUTPUT);       // Set IO1 to output
    pinMode(IO2, OUTPUT);       // Set IO2 to output
    pinMode(IO3, OUTPUT);       // Set IO3 to output
    digitalWrite(IO3, LOW);     // Set PwrEn to logic high
    digitalWrite(IO1, LOW);     // Set Reset to logic low
    digitalWrite(IO2, LOW);     // Set PwrKey to logic high
}












