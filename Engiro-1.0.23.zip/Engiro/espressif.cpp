#include "espressif.h"
#include "engiro.h"


void ESP::Modem_Disable() { 	// Reset Modem 
	pinMode(IO5, OUTPUT);
	digitalWrite(IO5, LOW);
}


void ESP::Modem_Enable() { 		// Release Modem Reset
	pinMode(IO5, OUTPUT);
	digitalWrite(IO5, HIGH);
}


void ESP::Pwr_Enable() { // Turn On WiFi Modem
    pinMode(IO6, OUTPUT);
    digitalWrite(IO6, HIGH);
}


void ESP::Pwr_Disable() { // Turn Off WiFi Modem
    pinMode(IO6, OUTPUT);
    digitalWrite(IO6, LOW);
}


bool ESP::isModemAvailable() { 	// Returns true if a valid modem response is received.
	ComSerial.println("AT");
	CS_ESP_RES res = serial_res(500,F("OK"));
	return(res.status);
}


bool ESP::echoOff() { 		// Switch AT command echo off.
	ComSerial.println("ATE0");
	CS_ESP_RES res = serial_res(500,F("OK"));
	return(res.status);
}


bool ESP::echoOn() { 		// Switch AT command echo on.
	ComSerial.println("ATE1");
	CS_ESP_RES res = serial_res(500,F("OK"));
	return(res.status);
}


bool ESP::wifiINIT() { 		// Initialize Wifi driver.
	ComSerial.println("AT+CWINIT=1");
	CS_ESP_RES res = serial_res(500,F("OK"));
	return(res.status);
}


bool ESP::wifiStationModeAutoConnect() {		// Set to Station Mode with auto-connect.
	ComSerial.println("AT+CWMODE=1,1");
	CS_ESP_RES res = serial_res(500,F("OK"));
	return(res.status);
}


bool ESP::wifiStationMode() {					// Set to Station Mode without auto-connect.
	ComSerial.println("AT+CWMODE=1,0");
	CS_ESP_RES res = serial_res(500,F("OK"));
	return(res.status);
}


bool ESP::wifiConnectAP(String ssid, String password) {			// Connect to AP with SSID and Password.
	ComSerial.print("AT+CWJAP=");
	ComSerial.println("\"" + ssid + "\"" + "," + "\"" + password + "\"");	
	CS_ESP_RES res = serial_res(10000,F("WIFI GOT IP"));
	String out = res.temp;
	Debug.println(out);	
	return(res.status);
	res = serial_res(500,F("OK"));	
}


bool ESP::wifiMqttPublishLong(String id, String topic, String length, String qos, String retain) {			// Publish Long MQTT Messages.
	ComSerial.print("AT+MQTTPUBRAW=");
	ComSerial.println(id + "," + "\"" + topic + "\"" + "," + length + "," + qos + "," + retain);	
	CS_ESP_RES res = serial_res(500,F("OK"));
	res = serial_res(500,F(">"));	
	String out = res.temp;
	Debug.println(out);	
	return(res.status);
}


bool ESP::wifiMqttSend(String data) {			// Publish Long MQTT Messages.
	ComSerial.println(data);
	CS_ESP_RES res = serial_res(10000,F("+MQTTPUB:OK"));
	String out = res.temp;
	Debug.println(out);	
	return(res.status);
}


bool ESP::wifiMqttConnect(String id, String ip, String port, String reconn) {				// Connect to MQTT Brokers.
	Debug.print("AT+MQTTCONN=");
	Debug.print(id);
	Debug.print(",");
	Debug.print("\"" + ip + "\"");
	Debug.print(",");
	Debug.print(port);
	Debug.print(",");
	Debug.println(reconn);	

	ComSerial.println("AT+MQTTUSERCFG=0,1,\"\",\"\",\"\",0,0,\"\"");
	delay(1000);
	ComSerial.print("AT+MQTTCONN=");
	ComSerial.print(id);
	ComSerial.print(",");
	ComSerial.print("\"" + ip + "\"");
	ComSerial.print(",");
	ComSerial.print(port);
	ComSerial.print(",");
	ComSerial.println(reconn);	
	CS_ESP_RES res = serial_res(5000,F("+MQTTCONNECTED"));
	String out = res.temp;
	Debug.println(out);	
	return(res.status);
	res = serial_res(500,F("OK"));	
}


bool ESP::wifiAutoConnectPowerOnEnable() {						// Enable auto connect AP during power on.
	ComSerial.println("AT+CWAUTOCONN=1");
	CS_ESP_RES res = serial_res(500,F("OK"));
	return(res.status);
}


bool ESP::wifiAutoConnectPowerOnDisable() {						// Disable auto connect AP during power on.
	ComSerial.println("AT+CWAUTOCONN=0");
	CS_ESP_RES res = serial_res(500,F("OK"));
	return(res.status);
}


bool ESP::wifiQuery() { 										// Query the Wi-Fi state and Wi-Fi information.
	ComSerial.println("AT+CWSTATE?");
	CS_ESP_RES res = serial_res(500,F("+CWSTATE:2"));
	String tmp;
	bool netStat = false;
	String data;
	data = res.data;
	Debug.println(data);
	if(res.status) {					
		netStat = true;
		Debug.println("Station has connected to an AP, and got an IPv4 address.");
	} else {
		netStat = false;
		Debug.println("Station has no connection.");
	}
	
	return (netStat);
}


String ESP::getGMR() { 			// Displays Version Information.
	ComSerial.println("AT+GMR");
	CS_ESP_RES res = serial_res(500,F("OK"));		
	String out = res.temp;
	return (out);
}


String ESP::getAPlist() { 		// Inquiry available access point.
	ComSerial.println("AT+CWLAP");
	CS_ESP_RES res = serial_res(10000,F("OK"));		
	String out = res.temp;
	return (out);
}


CS_ESP_RES ESP::serial_res(long timeout,String chk_string) {
	unsigned long pv_ok = millis();
	unsigned long current_ok = millis();
	String input;
	unsigned char until=1;
	unsigned char res=-1;
	CS_ESP_RES res_;
	res_.temp="";
	res_.data="";

	while(until) {
		if(ComSerial.available()) {
			input = ComSerial.readStringUntil('\n');
			res_.temp+=input;
			if(input.indexOf(chk_string)!=-1) {
				res=1;
				until=0;
			} else if(input.indexOf(F("ERROR"))!=-1) {
				res=0;
				until=0;
			}
		}
		current_ok = millis();
		if (current_ok - pv_ok>= timeout) {
			until=0;
			res=0;
			pv_ok = current_ok;
		}
	}
	res_.status = res;
	res_.data = input;
	return(res_);
}