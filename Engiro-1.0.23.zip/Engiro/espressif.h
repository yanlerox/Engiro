#include "Arduino.h"

struct CS_ESP_RES {
	unsigned char status;
	String data;
	String temp;
};


class ESP {
  public:
  // Public API Functions starts here.
    void Modem_Disable();       // Reset Modem
    void Modem_Enable();        // Release Modem Reset
    void Pwr_Enable();          // Enable Modem
    void Pwr_Disable();         // Disable Modem


  // Basic AT commands        
    bool isModemAvailable();    // Returns true if a valid modem response is received.
    bool echoOff();             // AT command echo off.
    bool echoOn();              // AT command echo on.
    String getGMR();		        // Displays Version Information.


  // WiFi AT commands
    bool wifiINIT(); 		        // Initialize Wifi driver.    
    bool wifiStationModeAutoConnect();		// Set to Station Mode with auto-connect.
    bool wifiStationMode();			// Set to Station Mode without auto-connect.
    String getAPlist(); 		    // Inquiry available access point.    
    bool wifiConnectAP(String ssid, String password);     // Connect to AP with SSID and Password.
    bool wifiMqttConnect(String id, String ip, String port, String reconn);      // Connect to MQTT Brokers.    
    bool wifiMqttPublishLong(String id, String topic, String length, String qos, String retain);      // Publish Long MQTT Messages.    
    bool wifiMqttSend(String data);			                  // Publish Long MQTT Messages.    
    bool wifiAutoConnectPowerOnEnable();						      // Enable auto connect AP during power on.
    bool wifiAutoConnectPowerOnDisable();						      // Disable auto connect AP during power on.
    bool wifiQuery();           // Query the Wi-Fi state and Wi-Fi information.


  private:
    CS_ESP_RES serial_res(long timeout, String chk_string);
};