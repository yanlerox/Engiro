/*
    Engiro.h - Library to define the Engiro SAMD board pinout to use in Arduino IDE environment.
    Created by Teng Kong Leong, August 21, 2023
    Released into the public domain.
*/

#include "Arduino.h"


 /* +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * >>>>>> ENGIRO PORT DEFINITION <<<<<<
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------*/
#define LED1                        13
#define LED2                        10
#define IO1                         0
#define IO2                         9
#define IO3                         4
#define IO4                         12
#define IO5                         6
#define IO6                         7
#define UART1_TX                    1
#define UART1_RX                    3
#define TX_ENABLE                   42
#define RX_ENABLE                   43
#define UART0_TX                    19
#define UART0_RX                    25
#define SPI_CS                      5
#define SPI_SCK                     24
#define SPI_MISO                    22
#define SPI_MOSI                    23
#define ACC_INT_1                   38
#define BATTERY                     8
#define ISENSE                      17
#define VSENSE                      18
#define SIGNAL1                     16
#define SIGNAL2                     15
#define SIG1                        26
#define SIG2                        27
#define AUX_PWR                     11
#define UART2_TX                    20
#define UART2_RX                    21


 /* +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * >>>>>> IIS328DQ ACCELEROMETER REGISTERS <<<<<<
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------*/
 
#define IIS328DQ_REG_WHO_AM_I       0x0F  // Chip identifier
#define IIS328DQ_REG_CTRL_REG1      0x20  // Set mode, ODR and enabled axes
#define IIS328DQ_REG_CTRL_REG3      0x22  // Interrupt control register
#define IIS328DQ_REG_CTRL_REG4      0x23  // Set scale
#define IIS328DQ_REG_OUT_X_L        0x28  // X-axis acceleration data in 2's complement. LSB
#define IIS328DQ_REG_OUT_X_M        0x29  // X-axis acceleration data in 2's complement. MSB
#define IIS328DQ_REG_OUT_Y_L        0x2A  // Y-axis acceleration data in 2's complement. LSB
#define IIS328DQ_REG_OUT_Y_M        0x2B  // Y-axis acceleration data in 2's complement. MSB
#define IIS328DQ_REG_OUT_Z_L        0x2C  // Z-axis acceleration data in 2's complement. LSB
#define IIS328DQ_REG_OUT_Z_M        0x2D  // Z-axis acceleration data in 2's complement. MSB
#define IIS328DQ_REG_INT1_CFG       0X30  // Configuration interrupt 1
#define IIS328DQ_REG_INT1_SRC       0X31  // Source interrupt 1
#define IIS328DQ_REG_INT1_THS       0X32  // Threshold interrupt 1
#define IIS328DQ_REG_INT1_DURATION  0X33
#define IIS328DQ_PM_NORMAL          0x20
#define IIS328DQ_ODR_100_CF_74      0x08
#define IIS328DQ_X_ENABLE           0x01  // Enable X-axis
#define IIS328DQ_Y_ENABLE           0x02  // Enable Y-axis
#define IIS328DQ_Z_ENABLE           0x04
#define IIS328DQ_FS_2               0x00  // +/- 2g
#define IIS328DQ_FS_4               0x10  // +/- 4g
#define IIS328DQ_FS_8               0x30  // +/- 8g
#define IIS328DQ_BDU_ENABLE         0X80
#define IIS328DQ_SLAVE_ADDR         0X18
#define MULTIPLE_BYTES_MASK         0X80    


 /* +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * >>>>>> RAK3172 LORAWAN AT COMMAND <<<<<<
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------*/
#define ATTENTION                   AT
#define FIRMWARE_VERSION            AT+VER=?


 /* +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * >>>>>> SYSTEM <<<<<<
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------*/
#ifdef __cplusplus

extern Uart Debug;
extern Uart ComSerial;
extern Uart Modbus;

#endif

struct MODBUS_RES {
    unsigned char status;
	String data;
	String temp;
};

    
 /* +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * >>>>>> FUNCTION PROTOTYPES <<<<<<
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------*/
class Engiro {
  public:
    // FUNCTION PROTOTYPE DECLARARIONS
    void Initialize();
    void Uart_Initialize();
    void Led1_On();
    void Led1_Off();
    void Led2_On();
    void Led2_Off();    
    void AuxPwr_Enable();
    void AuxPwr_Disable();
    unsigned int Battery();  
    unsigned int AnalogVoltageRead();
    unsigned int AnalogCurrentRead();
    void Modbus_Transmit_Enable();
    void Modbus_Receive_Enable();
    void Modbus_Sleep();
    void Acc_Initialize();
    void Acc_RW_Enable();
    void Acc_RW_Disable();
    void LoRa_RAK3172_Reset();
    void LoRa_RAK3172_Enable();
    void LoRa_RAK3172_Disable();
    void LTE_enable();
    void LTE_reset();
    void LTE_disable();
};

